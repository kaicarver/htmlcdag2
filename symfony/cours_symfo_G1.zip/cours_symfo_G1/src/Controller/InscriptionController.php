<?php

namespace App\Controller;
use App\Form\InscriptionFormType;
use App\Entity\Utilisateur;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;

class InscriptionController extends AbstractController
{
    #[Route('/inscription', name: 'app_inscription')]
    public function inscription(Request $request, UserPasswordHasherInterface $hashpwd, ManagerRegistry $doctrine): Response
    {
        $user = new Utilisateur();
        $form = $this->createForm(InscriptionFormType::class, $user);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em = $doctrine->getManager();
            $user->setEmail($form->get("email")->getData());
            $user->setPassword($hashpwd->hashPassword($user,$form->get("password")->getData()));
            $user->setRoles($form->get("roles")->getData());
            $em->persist($user);
            $em->flush();
            //redirection page login
            $this->redirectToRoute('app_login');
        }
        return $this->render('inscription/index.html.twig', [
            'f' => $form->createView()
        ]);
    }
}
