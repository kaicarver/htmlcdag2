<?php

namespace App\Controller;
use App\Entity\Categorie;
use App\Entity\Produit;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProduitController extends AbstractController
{
    #[Route('/ListeproduitsCat', name: 'list_prodByCat_produit')]
    public function ListeproduitsCat(ManagerRegistry $doctrine): Response
    {
        $cat = $doctrine->getRepository(Categorie::class)->find(4);
        return $this->render('produit/index.html.twig', [
            'listProdByCat' => $cat->getProduits(),
        ]);
    }
  

    #[Route('/addProductToCat', name: 'add_produit')]
    public function ajouterProds(ManagerRegistry $doctrine): Response
    {
        $em = $doctrine->getManager();
        $cat = new Categorie();
        $cat->setNomCat("Décoration");
        for($i=1;$i<=3;$i++){
            $produit = new Produit();
            $produit->setNomProduit("Miroir ".$i);
            $produit->setPrix(rand(60,150));
            $cat->addProduit($produit);
            $em->persist($produit);

        }
        $em->persist($cat);
        $em->flush();

        return new Response("add Cat with products");
    }
}
