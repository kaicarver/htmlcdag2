<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    #[Route('/home/{msg}', name: 'app_home')]
    public function index($msg): Response
    {
        return $this->render('home/index.html.twig',['utilisateurs'=>$msg]);


    }

    #[Route('/accueil', name: 'app_accueil')]
    public function afficherAcc(): Response
    {

        return $this->render('home/indexT.html.twig');
    }

    #[Route('/json', name: 'app_json')]
    public function afficherJson(): Response
    {
        return $this->json(["username"=>"jhon"]);
    }


    #[Route('/site', name: 'app_site')]
    public function afficherSite(): Response
    {
        return $this->redirect("https://symfony.com/");
    }

    #[Route('/redirectpage', name: 'app_page')]
    public function afficherAutrePage(): Response
    {
        return $this->redirectToRoute("app_home",["msg"=>"oo"]);
    }

    #[Route('/prenom/{p?}', name: 'app_param')]
    public function afficherParams($p): Response
    {
        return new  Response("Bonjour " .$p);
    }


}
