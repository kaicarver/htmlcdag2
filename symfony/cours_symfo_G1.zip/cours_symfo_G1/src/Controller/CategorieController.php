<?php

namespace App\Controller;

use App\Entity\Categorie;
use App\Form\CategorieFormType;
use Symfony\Component\HttpFoundation\Request;

use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

class CategorieController extends AbstractController
{
    #[Route('/listcategories', name: 'list_categorie')]
    public function index(ManagerRegistry $doctrine): Response
    {
        $cats = $doctrine->getRepository(Categorie::class)->findAll();

        return $this->render('categorie/list.html.twig', [
            'cats' => $cats,
        ]);
    }

    #[Route('/addCategorie', name: 'add_categorie')]
    #[IsGranted('ROLE_USER')]
    public function ajouterCategorie(ManagerRegistry $doctrine,Request $request  ): Response
    {
        $em=  $doctrine->getManager();
        // créer un objet categorie vide
        $cat = new Categorie();
        // créer le formulaire
        // en symfony formulaire est lié à une entité
        $form  = $this->createForm(CategorieFormType::class,$cat);
        //Préparer les données saisies au niveau du formulaire
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid() ){
            // persist() prépare les données lors de la créaction
            $em->persist($cat);
             // sauvegarder les infos dans la bd
            $em->flush();
            return $this->redirectToRoute("list_categorie");
        }

        return $this->render('categorie/add.html.twig', [
            'f' => $form->createView()
        ]);
    }


    #[Route('/deleteCategorie/{id}', name: 'delete_categorie')]
    public function supprimerCategorie(ManagerRegistry $doctrine, Categorie $cat  ): Response
    {

        $em=  $doctrine->getManager();
        /*$prods = $cat->getProduits();
        foreach($prods as $prod){
            $prod->setCategorie(null);
            $em->flush();

        }*/

        $em->remove($cat);
        // sauvegarder les infos dans la bd
        $em->flush();
        return $this->redirectToRoute("list_categorie");

    }


    #[Route('/editCategorie/{id}', name: 'edit_categorie')]
    public function modifierCategorie(ManagerRegistry $doctrine, Categorie $cat, request $request ): Response
    {
        $em=  $doctrine->getManager();

        $form  = $this->createForm(CategorieFormType::class,$cat);
        //Préparer les données saisies au niveau du formulaire
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid() ){
            $em->persist($cat);
            $em->flush();
            return $this->redirectToRoute("list_categorie");
        }
        return $this->render('categorie/edit.html.twig', [
            'f' => $form->createView()
        ]);
    }

    #[Route('/listCategories', name: 'list_categorie')]
    public function afficherCategories(ManagerRegistry $doctrine): Response
    {
        $cats = $doctrine->getRepository(Categorie::class)->findAll();
        //$cat = $doctrine->getRepository(Categorie::class)->findBy(["nomCat"=>"lits et matelats"]);

        return $this->render('categorie/list.html.twig', [
            'cats' => $cats,
        ]);
    }
}
