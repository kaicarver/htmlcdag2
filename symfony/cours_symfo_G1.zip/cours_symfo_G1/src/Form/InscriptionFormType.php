<?php

namespace App\Form;

use App\Entity\Utilisateur;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;


use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\CallbackTransformer;

class InscriptionFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
        //<input name="nom" type='text' class=""form-control mt-2"">
            ->add('nom',TextType::class,['attr'=>['class'=>"form-control mt-2"]])
                    //<input name="nom" type='email' class="form-control mt-2">

            ->add('email',EmailType::class,['attr'=>['class'=>"form-control mt-2"]])
                    //<input name="password" type='password' class="form-control mt-2">

            ->add('password',RepeatedType::class,[
                'type'=>PasswordType::class,
                'first_options'=>['label'=>'Mot de passe','attr'=>['class'=>"form-control mt-2"]],
                'second_options'=>['label'=>'Mot de passe(vérification)','attr'=>['class'=>"form-control mt-2"]]

            ])
            /*
            <label>Rôles</label>
            <select name="roles" class="form-select mt-2" multiple >
                  <option value="ROLE_ADMIN">Administrateur</option>
                  <option value="'ROLE_USER'">Utilisateur</option>

            </select>


            */
            ->add('roles',ChoiceType::class,[
                'required' => true,
                    'multiple' => true,
                    'expanded' => false,
                    'choices' =>
                    [
                        'Administrateur' => 'ROLE_ADMIN',
                        'Utilisateur' => 'ROLE_USER'
                    ],
                    'label'=>"Rôles",
                    'attr' => ['class' => 'form-select mt-3']

            ])
            ->add('save',SubmitType::class,['label'=>"Ajouter utilisateur",'attr'=>['class'=>"btn btn-primary mt-3"]])
        ;
        

    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Utilisateur::class,
        ]);
    }
}
