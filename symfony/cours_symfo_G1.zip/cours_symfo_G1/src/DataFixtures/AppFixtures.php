<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\Categorie;
use Faker\Generator;
use Faker\Factory;
use App\Entity\Utilisateur;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class AppFixtures extends Fixture
{
    private Generator $faker;
    private $userPasswordHasherInterface;

    public function __construct(UserPasswordHasherInterface $userPasswordHasherInterface)
    {
        $this->faker = Factory::create('fr_FR');
        $this->userPasswordHasherInterface = $userPasswordHasherInterface;

    }
    public function load(ObjectManager $manager): void
    {
        // Ajouter un admin
        $users =[];
        $admin = new Utilisateur();
        /*$admin->setEmail('admin@gmail.com');
        $admin->setRoles(['Role_USER','ROLE_ADMIN']);*/
       $admin->setEmail('admin@gmail.com')->setRoles(['Role_USER','ROLE_ADMIN'])->setPassword($this->userPasswordHasherInterface->hashPassword($admin,'admin123'))->setNom("ADMIN");
       $users[]=$admin;
       $manager->persist($admin);
       //ajouter des utilisateurs aves role Role_USER
       for($j=0;$j<10;$j++){
        $user = new Utilisateur();
        $user->setEmail($this->faker->email())->setRoles(['Role_USER'])->setPassword($this->userPasswordHasherInterface->hashPassword($user,'user123'))->setNom($this->faker->name());
        $users[] = $user;
        $manager->persist($user);
        $manager->flush();

       }
        // ajouter des catégories dans la base de données de test
        $cats = [];
        for ($i = 0; $i < 10; $i++) {
            $cat = new Categorie();
            $cat->setNomCat($this->faker->word());
            $cats[] = $cat;
            $manager->persist($cat);
        }
        $manager->flush();
    }
}
