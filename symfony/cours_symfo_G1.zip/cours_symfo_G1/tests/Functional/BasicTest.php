<?php

namespace App\Tests\Functional;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class BasicTest extends WebTestCase
{
    public function testSomething(): void
    {
        // $client simule un navigateur, Au lieu de faire des appels HTTP au serveur, il appelle directement l'application symfony
        $client = static::createClient();
        $crawler = $client->request('GET', '/accueil');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h2', 'Voici la liste des utilisateurs');
    }

}
