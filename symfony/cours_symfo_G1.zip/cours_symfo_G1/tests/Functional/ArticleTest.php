<?php

namespace App\Tests\Functional;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\Utilisateur;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ArticleTest extends WebTestCase
{
    public function testFormCat(): void
    {
        $client = static::createClient();
        $urlGenerator = $client->getContainer()->get('router');
        // récupérer un user
        $em = $client->getContainer()->get('doctrine.orm.entity_manager');
        $user = $em->find(Utilisateur::class,1);
        // login
        $client->loginUser($user);
        $crawler = $client->request(Request::METHOD_GET, $urlGenerator->generate('add_categorie'));
        $form = $crawler->filter('form[name=categorie_form]')->form([
         'categorie_form[nomCat]' => "Lits et matlats",
            ]);
        $client->submit($form);
        $this->assertResponseStatusCodeSame(Response::HTTP_FOUND);
        $client->followRedirect();
        $this->assertRouteSame('list_categorie');
    }
}
