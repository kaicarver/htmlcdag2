<?php

namespace App\Tests\Unit;
use App\Entity\Article;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class ArticleTest extends KernelTestCase
{
    public function testSomething(): void
    {
        self::bootKernel();
        $container =static::getContainer();
        $article = new Article();
        $article->setTire("");
        $erreur = $container->get('validator')->validate($article);
        // demander que les erreurs = 0
        $this->assertCount(2,$erreur);



    }
}
