<?php

namespace App\Tests\Unit;

use PHPUnit\Framework\TestCase;

class BasicTest extends TestCase
{
    public function testSomething(): void
    {
        $this->assertTrue(true);
    }
}
